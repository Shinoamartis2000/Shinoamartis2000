package Prevalent;

import Model.SettingsUsersInfo;
import Model.Users;

public class Prevalent {

    public static Users currentOnLineUsers;
    //public static SettingsUsersInfo currentOnlineUserInfo;

    public static final String UserEmailKey = "email";
    public static final String UserPasswordKey = "password";





}
